#include <stdlib.h>
#include <stdint.h>
#include <stdio.h>
#include <avr/io.h>


void SRAM_test(void);