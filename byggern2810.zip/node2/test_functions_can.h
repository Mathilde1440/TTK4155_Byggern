#ifndef TEST_FUNCTIONS_CAN_H_
#define TEST_FUNCTIONS_CAN_H_


#include <stdio.h>
#include <stdint.h>
#include <stdarg.h>
#include "can_controller.h"


void print_message_object_node_2(CAN_MESSAGE* message);
void test_rec_node_1();
void test_JS_driver();




#endif 