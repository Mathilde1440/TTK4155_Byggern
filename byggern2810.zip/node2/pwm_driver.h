#ifndef PWM_DRIVER_H_
#define PWM_DRIVER_H_

#include <stdio.h>
#include <stdint.h>
#include <stdarg.h>


void timer_counter_init();

#endif
