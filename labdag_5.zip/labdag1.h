#ifndef LABDAG1_H
#define LABDAG1_H
#include <avr/io.h>

#include "uart.h"
#include "sram.h"
#include <stdio.h>


void test_med_echo();
void firkantpuls();

#endif
