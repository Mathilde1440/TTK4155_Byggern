#ifndef ENCODER_H_
#define ENCODER_H_

#include <stdio.h>
#include <stdint.h>
#include <stdarg.h>

void encoder_init();
int32_t read_encoder_pos();

#endif