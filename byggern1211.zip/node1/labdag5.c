#include "labdag5.h"



    //while (1){
    
        //test_med_echo();
     
        //printf("ing");  //printf

        //test_for_latch();
    //}
    //while(1){
        //_delay_ms(2000);
        //adc_kick();
        
        //volatile v = adc_read0();
        //_delay_ms(2000);
        //void(v);
        
    //}

    