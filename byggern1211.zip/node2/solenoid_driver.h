#ifndef SOLENOID_DRIVER_H_
#define SOLENOID_DRIVER_H_


#include <stdio.h>
#include <stdint.h>
#include <stdarg.h>

void solenoid_init();
int solenoid_activate(int place_holder_value);


#endif
